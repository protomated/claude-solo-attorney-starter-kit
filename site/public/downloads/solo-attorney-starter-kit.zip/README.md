# Solo Attorney Claude Starter Kit — Claude Desktop Plugin

A Claude Desktop plugin that turns your local matter files, Gmail, and Google Calendar into a solo attorney operations assistant. Six pre-built skills: intake summaries, engagement letters, court deadline reasoning, meeting prep briefs, billing narrative drafting, and new-matter setup — from your own files, in under five minutes of setup.

**Distributed by [Protomated](https://protomated.com) as a free download.**

---

## ⚠️ Required: Read This Before You Install

**This section is not boilerplate. Read it before connecting client data.**

### 1. You must be on a qualifying Claude plan

Do NOT use this plugin for client work on a consumer Claude plan (claude.ai Personal or Claude Pro). Consumer plans do not provide a Data Processing Agreement (DPA) covering client-privileged content.

You must be on one of the following before using this plugin with real client materials:

- **Claude for Work** (formerly Claude.ai Teams)
- **Claude Team or Enterprise**
- **Claude API** (with a signed DPA from Anthropic)

Using a consumer plan with client-privileged content risks waiving attorney-client privilege and may violate your ethical obligations to your clients. See *United States v. Heppner* (S.D.N.Y. Feb. 2026) and your state bar's AI ethics guidance before proceeding.

> **If you're not sure which plan you're on:** Open Claude Desktop → Help → About. If it says "Claude Pro," you are on a consumer plan. Upgrade to Claude for Work or obtain API access before connecting client email or matter files.

### 2. Informed consent — update your engagement letter

**ABA Formal Op. 512 (July 2024)** requires attorneys using AI tools in client work to obtain client informed consent where the AI tool may access confidential information.

Before using this plugin on any active matter, add AI-tool disclosure language to your engagement letters. Suggested language for new clients:

> "Our firm uses AI-assisted drafting and research tools, including Claude Desktop, to improve the efficiency of certain practice tasks. These tools process information under agreements that protect confidentiality consistent with our professional obligations. We will not use AI tools in your matter in any way that compromises the attorney-client privilege or your confidential information."

Consult your state bar's guidance on AI disclosure obligations — requirements vary by jurisdiction.

### 3. Every AI output requires your review

This plugin is a drafting tool. It does not provide legal advice. Every document it generates — status updates, demand letters, engagement letters, intake summaries, and meeting briefs — must be reviewed and approved by you, a licensed attorney, before use.

The plugin enforces this with a required header and footer on every output:

> ⚠️ AI-ASSISTED DRAFT — ATTORNEY REVIEW REQUIRED

Do not remove or bypass these markers.

### 4. No action without your confirmation

The plugin is instructed to request your explicit in-conversation confirmation before sending any email or writing any file. If you are ever prompted by the assistant to confirm a send or write action, read the confirmation carefully before responding.

---

## Installation (5 minutes)

### Step 1 — Download and install

1. Download `solo-attorney-starter-kit.zip` from the [Releases page](https://github.com/protomated/claude-solo-attorney-starter-kit/releases).
2. Double-click the `.zip` file, or drag it into Claude Desktop's **Extensions** panel.
3. Claude Desktop will install the plugin and prompt you to connect the required services.

### Step 2 — Connect Gmail

1. Go to **Claude Desktop → Settings → Connectors**.
2. Find **Gmail** and click **Connect**.
3. Sign in with the Google account that holds your client correspondence.
4. Grant the requested permissions. Anthropic manages the OAuth credentials — your Google password is never shared with Protomated.

### Step 3 — Connect Filesystem (your matters folder)

1. In **Settings → Connectors**, find **Filesystem** and click **Connect**.
2. Select the folder on your computer where your matter files live. Example: `~/Matters` or `~/Documents/Cases`.
3. Only files inside this folder will be accessible to the plugin.

> **Recommended folder structure:**
> ```
> ~/Matters/
> ├── templates/
> │   └── engagement-letter-template.md
> ├── Smith-John-PI/
> │   ├── intake-summary.md
> │   ├── tasks.md
> │   ├── medical/
> │   └── correspondence/
> ├── Acme-Contract-Dispute/
> │   ├── intake-summary.md
> │   ├── tasks.md
> │   └── pleadings/
> └── ...
> ```
> Run `/new-matter-organizer` to create this structure for a new matter, then `/intake-summary` to populate the anchor file all other skills read from. If you have your own engagement-letter template, save it once as `templates/engagement-letter-template.md` (or `.txt`/`.docx`) and `/engagement-letter` will use it automatically for every matter.

### Step 4 — Connect Google Calendar

1. In **Settings → Connectors**, find **Google Calendar** and click **Connect**.
2. Sign in with the same Google account you use for scheduling.
3. This connector is used by `/court-deadline` to create deadline events after your confirmation.

### Step 5 — Verify

Open a new Claude Desktop chat. Type `/skills`. You should see all six skills listed. Run `/intake-summary` on a test matter to verify Filesystem access is working.

See [CONNECTORS.md](CONNECTORS.md) for troubleshooting.

---

## Skills

### `/intake-summary` — Intake Summary Processor

**Run this first on any new matter.** Converts raw intake notes or pasted consultation notes into a structured case brief: parties, facts, claims, deadlines, evidence checklist, and next steps. Flags statute-of-limitations issues and surfaces names for a conflicts check. The output becomes the `intake-summary.md` that all other skills read from.

**Use when:** You've just finished an initial consultation and need to open the file.

```
/intake-summary
[paste your raw notes]

/intake-summary ~/Matters/New-Client-Folder
```

---

### `/engagement-letter` — Engagement Letter Drafter

Drafts a retainer and engagement letter from intake data. If you've saved your own template at `templates/engagement-letter-template.md` (or `.txt`/`.docx`) at the top of your Matters folder, or in the specific matter folder, the skill fills in your own wording instead of the built-in generic letter. Covers scope of representation, fee structure (hourly, flat fee, or contingency), client obligations, and required disclosures. Requires your confirmation before saving.

**Use when:** A new client is ready to retain you.

```
/engagement-letter New-Client-Johnson
/engagement-letter ~/Matters/Johnson-Family-Law
```

---

### `/court-deadline` — Court Deadline Reasoning & Calendar Drafter

Computes a court or filing deadline from a trigger date and the rule you provide. Shows every step of the reasoning so you can verify it. Drafts a Google Calendar event — you confirm before it is created. Does not maintain a jurisdiction-specific rule database; you supply the rule and verify the output.

**Use when:** You need to calculate a response deadline, appeal window, or statute-of-limitations date and want the reasoning shown step by step.

```
/court-deadline "served May 12" "responsive pleading due 21 days after service, excluding weekends and federal holidays"
```

---

### `/meeting-prep` — Meeting Prep Brief Generator

Pulls context from your matter folder and recent email to produce a one-page brief tailored to the meeting type: client check-in, deposition, mediation, settlement conference, or court appearance. Read-only — no files are written.

**Use when:** You have five minutes before a meeting and need to get up to speed fast.

```
/meeting-prep Smith-John-PI deposition
/meeting-prep ~/Matters/Acme-Contract-Dispute mediation
```

---

### `/billing-narrative` — Billing Narrative Drafter

Drafts a billing-code-appropriate time narrative and suggests a time increment from your rough notes, an email thread, or a description of work performed. You confirm accuracy and paste into your billing system (Clio, MyCase, PracticePanther, etc.).

**Use when:** You've completed billable work and need a clean, professional time entry without spending ten minutes writing it yourself.

```
/billing-narrative "reviewed deposition transcript, drafted summary memo, called client re: settlement offer — approx 2 hrs"
```

---

### `/new-matter-organizer` — New-Matter Setup & Document Organizer

Creates the standard folder tree for a new matter (based on practice area), populates a starter task checklist, and sorts any existing documents into the right sub-folders. Proposes everything first — no folders or files are created without your confirmation.

**Use when:** Opening a new client file and you want a consistent, organized matter folder from day one.

```
/new-matter-organizer "Smith-John-PI" "personal injury"
/new-matter-organizer "Nguyen-Divorce-2026" "family law"
```

---

> Need the AI-adjusted flat-fee repricing calculator too? `/flat-fee-calculator` is now its own standalone plugin — **Flat-Fee Repricing Calculator** — in the [Protomated plugin marketplace](https://github.com/protomated/protomated-plugins-official), so it can be installed independently of this kit.

---

## How It Works

This plugin connects Claude Desktop to three things you already have: your local matter files, your Gmail, and your Google Calendar. There is no cloud database, no subscription, and no Protomated server involved in processing your client data.

```
Your matter files (Filesystem) ──┐
                                  │
Your Gmail (Gmail connector) ─────┼──▶ Claude Desktop ──▶ Your review ──▶ Action
                                  │
Your Calendar (Google Calendar) ──┘
```

All processing happens inside your Claude Desktop session. See [CONNECTORS.md](CONNECTORS.md) for data handling details.

---

## Optional Connectors

Not every skill needs all three connectors, and none of them are hard-required to get value from this kit:

- **Filesystem** is the one most skills lean on, but even here `/intake-summary` and `/billing-narrative` work entirely from notes you paste in — no connected folder needed. Skills that write to the matter folder (`/new-matter-organizer`, `/engagement-letter`) will simply ask you to paste text or confirm a save location if it isn't connected.
- **Gmail** is used only as *supplementary* context — `/meeting-prep` checks recent email for developments, and `/engagement-letter` checks for agreed fee terms. Both skills work fully without it; they just skip the email-context step.
- **Google Calendar** is used only by `/court-deadline`'s final step. The deadline computation and its full reasoning happen with or without this connector — Calendar is only needed if you want the confirmed date turned into a calendar event automatically.

Connect only what you plan to use. Skills degrade gracefully and will tell you what they couldn't check.

---

## Want a Custom Skill Library Built for Your Practice?

This kit covers six core workflows. The typical solo practice has 15–20 more: jurisdiction-specific court filings, intake questionnaires tuned to your practice areas, Clio or Filevine integration, and skills built to your exact voice and playbook.

**Protomated builds custom Claude Desktop skill libraries for solo and small-firm attorneys: $3,000–$6,000 depending on scope.**

[Book a 30-minute call →](https://protomated.com/call)

---

## License

Apache 2.0. See [LICENSE](LICENSE).

## Feedback and Issues

[GitHub Issues](https://github.com/protomated/claude-solo-attorney-starter-kit/issues) | [hello@protomated.com](mailto:hello@protomated.com)
